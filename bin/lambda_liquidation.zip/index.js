﻿const AWS = require('aws-sdk');
const db = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
    const { reu, master_hash, total_eventos } = JSON.parse(event.body);
    const valor_evento = 75.00;
    const valor_lote = (total_eventos || 5) * valor_evento;

    const params = {
        TableName: "DataEquity_Contador_Global",
        Key: { "id": "total_soberania" },
        UpdateExpression: "SET valor_acumulado = valor_acumulado + :val, ultima_atualizacao = :ts",
        ExpressionAttributeValues: {
            ":val": valor_lote,
            ":ts": new Date().toISOString()
        },
        ReturnValues: "UPDATED_NEW"
    };

    try {
        const result = await db.update(params).promise();
        console.log(\[LIQUIDAÇÃO] R$ \ contra \. Hash: \\);
        return {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "*" },
            body: JSON.stringify({ 
                status: "Lote Aceito", 
                acumulado: result.Attributes.valor_acumulado 
            })
        };
    } catch (error) {
        console.error(error);
        return { statusCode: 500, body: "Falha na indexação de liquidação" };
    }
};
